let userName = prompt('Как вас зовут?','');
let userAge = prompt('Сколько вам лет?','');

alert(`Здраствуйте ${userName}, ${userAge} лет :)`);

// alert("Здраствуйте " + userName + ", " + userAge + " лет");