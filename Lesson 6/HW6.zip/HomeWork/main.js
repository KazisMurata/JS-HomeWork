
// привести примеры их использования


// 1) площадь круга
// 2) длину окружности

function Circle(r) {
    return {
        calculateSquare() {
            return +(3.1415 * (r ** 2)).toFixed(2);
        },
        
        calculateCircumference() {
            return +(2 * 3.1415 * r).toFixed(2);
        }
    }
}

let circle = new Circle(10);

console.log(`Площадь круга ${circle.calculateSquare()}`);
console.log(`Длина окружности ${circle.calculateCircumference()}`);


// 3) среднее арифметическое двух чисел
// 4) среднее арифметическое массива (массив чисел)


function ArithmeticalMean(a, b) {
    return {
        twoNumbers() {
            return (a + b) / 2;
        },
        
        arr() {
            let arithmeticalMean = 0;
            let count = 0;
            for (let i = 0; i < a.length; i++) {
                arithmeticalMean += a[i];
                count++;
            };
            return +(arithmeticalMean / count).toFixed(2);
        }
    }
}

let arithmeticalMeanNumbers = new ArithmeticalMean(123, 22);
let arithmeticalMeanArr = new ArithmeticalMean([123, 22, 2, 3, 4, 10]);

console.log(`Cреднее арифметическое двух чисел ${arithmeticalMeanNumbers.twoNumbers()}`);
console.log(`Cреднее арифметическое массива  ${arithmeticalMeanArr.arr()}`);

// Примеры их использования:

// Для решения геометрических задач 
// Возможно для создания инжинерного калькулятора




